from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__,static_url_path='/static')

# Load the machine learning model
model = pickle.load(open('Insurance.pkl', 'rb'))
@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])

def predict():
    age = int(request.form.get("1"))
    gender= str(request.form.get("2"))
    bmi = float(request.form.get("3"))
    child = int(request.form.get("4"))
    smoker = str(request.form.get("5"))
    region = str(request.form.get("6"))
    

    # test_input =[19,'female',27.900,0,'yes','southwest']
    user_input =[
        age ,gender, bmi, child, smoker, region
    ]
    prediction = model.predict(np.array(user_input).reshape(1, -1))
    prediction=str(prediction)
    print(prediction)

    return render_template("result.html", prediction=prediction,user_input=user_input)

    

if __name__ == "__main__":
    app.run(debug=True)

